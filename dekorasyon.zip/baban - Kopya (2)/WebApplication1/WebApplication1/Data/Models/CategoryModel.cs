﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Models
{
    public class CategoryModel
    {
        [Key]
        public int CategoryId { get; set; }
        [Required(ErrorMessage = "Kategori ismi girin")]
        [StringLength(50)]
        public string CategoryName { get; set; }
        public List<GameModel> Games { get; set; }
    }
}
