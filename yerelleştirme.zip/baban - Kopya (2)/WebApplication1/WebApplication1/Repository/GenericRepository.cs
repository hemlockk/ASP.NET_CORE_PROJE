﻿
using WebApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Repository
{
    public class GenericRepository<T> where T: class,new()
    {
        Context c = new Context();
            public List<T> List()
        {
            return c.Set<T>().ToList();
        }
        public void Add(T p)
        {
             c.Set<T>().Add(p);
            c.SaveChanges();
        }
        public void Delete(T p)
        {
            c.Set<T>().Remove(p);
            c.SaveChanges();
        }
        public void Update(T p)
        {
            c.Set<T>().Update(p);
            c.SaveChanges();
        }
        public T Get(int id)
        {
            return c.Set<T>().Find(id);
        }
        public List<T> List(string p)
        {
            return c.Set<T>().Include(p).ToList();
        }
    }
}
