﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using WebApplication1.Models;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{
    [AllowAnonymous]
    public class UserController : Controller
    {
        
        Context context = new Context();
        UserRepository userRepository = new UserRepository();
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(UserModel p)
        {
            if (!ModelState.IsValid)
            {
                return View("Index");
            }
            var datavalue = context.Users.FirstOrDefault(x => x.Email == p.Email && x.Password == p.Password);
            if(datavalue != null)
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name,p.Email),
                    new Claim(ClaimTypes.Role,"Admin")
                };
                var userIdentity = new ClaimsIdentity(claims, "Login");
                ClaimsPrincipal principal = new ClaimsPrincipal(userIdentity);
                await HttpContext.SignInAsync(principal);
                TempData["error"] = "0";
                return RedirectToAction("Index", "Home");

            };
            TempData["error"] = "1";
            return View();
        }
        /*
        private object ClaimsIdentity(List<Claim> claims, string v)
        {
            throw new NotImplementedException();
        }
        */
        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "User");
        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public IActionResult Register(UserModel p)
        {
            if (!ModelState.IsValid)
            {
               return View("Register");
            }
            var datavalue = context.Users.FirstOrDefault(x => x.Email == p.Email);
            if(datavalue != null)
            {
                TempData["error2"] = "1";
                return View();
            }
            TempData["error2"] = "0";
            userRepository.Add(p);
            return RedirectToAction("Register", "User");

        }
    }
}
