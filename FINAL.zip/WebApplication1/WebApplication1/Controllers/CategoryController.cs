﻿using WebApplication1.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;
using X.PagedList;
using Microsoft.AspNetCore.Authorization;

namespace WebApplication1.Controllers
{
    public class CategoryController : Controller
    {
        CategoryRepository categoryRepository = new CategoryRepository();
        public IActionResult CList()
        {
            return View(categoryRepository.List());
        }
        [HttpGet]
        public IActionResult CategoryAdd()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CategoryAdd(CategoryModel x)
        {
            if (!ModelState.IsValid)
            {
                return View("CategoryAdd");
            }
            categoryRepository.Add(x);
            return RedirectToAction("CList");
        }
        public IActionResult CategoryDelete(int Id)
        {
            categoryRepository.Delete(new CategoryModel { CategoryId = Id});
            return RedirectToAction("CList");
        }
        public IActionResult CategoryGet(int Id)
        {
            var x = categoryRepository.Get(Id);
            CategoryModel category = new CategoryModel()
            {
                CategoryName = x.CategoryName,
                CategoryId = x.CategoryId
            };
            return View(category);
        }
        [HttpPost]
        public IActionResult CategoryUpdate(CategoryModel p)
        {
            var x = categoryRepository.Get(p.CategoryId);
            x.CategoryName = p.CategoryName;
            categoryRepository.Update(x);
            return RedirectToAction("Clist");
        }
    }
}
