using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Mvc.Razor;
using System.Globalization;
using Microsoft.AspNetCore.Localization;

namespace WebApplication1
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(Config => {
                var policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
                Config.Filters.Add(new AuthorizeFilter(policy));
            });
            services.AddLocalization(opt => { opt.ResourcesPath = "Resources"; });
            services.AddMvc()
                .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
                .AddDataAnnotationsLocalization();
            services.AddMvc();
            services.Configure<RequestLocalizationOptions>(
                opt => {
                    var SupportedLanguages = new List<CultureInfo>
                {
                    new CultureInfo("tr"),
                    new CultureInfo("en")
                };
                    opt.DefaultRequestCulture = new RequestCulture("tr");
                    opt.SupportedCultures = SupportedLanguages;
                    opt.SupportedUICultures = SupportedLanguages;

                    });
            services.AddAuthentication(
                CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(x => { x.LoginPath = "/User/Index";
                    x.AccessDeniedPath = "/User/Index";
                });
            services.AddRazorPages()
                .AddMvcOptions(options =>
                {
                    options.ModelBindingMessageProvider.SetValueMustNotBeNullAccessor(
                        _ => "Bu alan bo� ge�ilemez.");
                });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();
            var SupportedLanguages = new[] { "tr", "en" };
            var LocalizationOptions = new RequestLocalizationOptions()
                .SetDefaultCulture(SupportedLanguages[0])
                .AddSupportedCultures(SupportedLanguages)
                .AddSupportedUICultures(SupportedLanguages);
            app.UseRequestLocalization(LocalizationOptions);
            app.UseRouting();
            app.UseStaticFiles();
            app.UseAuthorization();
            app.UseAuthentication();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
