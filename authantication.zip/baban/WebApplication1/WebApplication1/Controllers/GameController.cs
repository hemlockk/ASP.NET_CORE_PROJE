﻿using WebApplication1.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;

namespace WebApplication1.Controllers
{
    public class GameController : Controller
    {
        GameRepository gameRepository = new GameRepository();
        Context Context = new Context();
        public IActionResult Index()
        {
            return View(gameRepository.List("Category"));
        }
        [HttpGet]
        public IActionResult GameAdd()
        {

            List<SelectListItem> values = (from x in Context.Categories.ToList()
                                           select new SelectListItem
                                           {
                                               Text = x.CategoryName,
                                               Value = x.CategoryId.ToString()
                                           }).ToList();
            ViewBag.v1 = values;

            return View();
        }
        [HttpPost]
        public IActionResult GameAdd(GameModel x)
        {
            if (!ModelState.IsValid)
            {
                return View("GameAdd");
            }
            gameRepository.Add(x);
            return RedirectToAction("Index");
        }
        public IActionResult GameDelete(int Id)
        {
            gameRepository.Delete(new GameModel { GameId = Id });
            return RedirectToAction("Index");
        }
        public IActionResult GameGet(int Id)
        {
            var x = gameRepository.Get(Id);
            GameModel gameModel = new GameModel()
            {
                GameId = x.GameId,
                Name = x.Name,
                Price = x.Price,
                Discount = x.Discount,
                ImagePath = x.ImagePath,
                CategoryId = x.CategoryId
            };
            List<SelectListItem> values = (from y in Context.Categories.ToList()
                                           select new SelectListItem
                                           {
                                               Text = y.CategoryName,
                                               Value = y.CategoryId.ToString()
                                           }).ToList();
            ViewBag.v1 = values;
            return View(gameModel);
        }
        [HttpPost]
        public IActionResult GameUpdate(GameModel p)
        {
            var x = gameRepository.Get(p.GameId);

            //x.GameId = p.GameId;
            x.Name = p.Name;
            x.Price = p.Price;
            x.Discount = p.Discount;
            x.ImagePath = p.ImagePath;
            x.CategoryId = p.CategoryId;

            gameRepository.Update(x);
            return RedirectToAction("Index");
        }
    }
}

