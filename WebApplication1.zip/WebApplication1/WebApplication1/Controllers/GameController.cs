﻿using WebApplication1.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class GameController : Controller
    {
        GameRepository gameRepository = new GameRepository();

        public IActionResult Index()
        {
            return View(gameRepository.List("Categories"));
        }
        [HttpGet]
        public IActionResult GameAdd()
        {
            return View();
        }
        [HttpPost]
        public IActionResult GameAdd(GameModel x)
        {
            gameRepository.Add(x);
            return RedirectToAction("Index");
        }

    }
}

