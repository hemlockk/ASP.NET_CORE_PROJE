﻿using WebApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class GameModel
    {
        [Key]
        public int GameId { get; set; }
        [Required(ErrorMessage = "Kategori ismi girin")]
        [StringLength(50)]
        public string Name { get; set; }
        [Required(ErrorMessage = "Fiyat giriniz")]
        [Range(0.99,10000)]
        public double Price { get; set; }
        public string ImagePath { get; set; }
        [Range(0, 101)]
        public double Discount { get; set; }
        public int CategoryId { get; set; }
        public virtual CategoryModel Category { get; set; }
    }
}
