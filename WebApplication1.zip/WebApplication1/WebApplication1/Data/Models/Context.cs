﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Models
{
    public class Context: DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("server=FAKBAY;database=NewDatabase;Integrated Security=True");
        }
        public DbSet<GameModel> Games { get; set; }
        public DbSet<CategoryModel> Categories { get; set; }
        public DbSet<AdminModel> Admins { get; set; }
        public DbSet<UserModel> Users { get; set; }

    }
}
